function change(element){
    element.src = "./assets/succulents-2.jpg"
}

function changeBack(element){
    element.src = "./assets/succulents-1.jpg"
}

function hide(element){
    element.remove();
}