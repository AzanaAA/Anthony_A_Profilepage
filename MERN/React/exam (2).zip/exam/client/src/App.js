import React from 'react';
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import PetEdit from"./components/PetEdit";
import PetForm from './components/PetForm';
import PetList from "./components/PetList";
import DisplayPet from './components/PetPage';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<PetList />} />
        <Route path="/new" element={<PetForm />} />
        <Route path="/edit/:id" element={<PetEdit />}/>
        <Route path="/pet/:id" element={<DisplayPet />}/>
      </Routes>


    </BrowserRouter>
    </div>
  );
}

export default App;