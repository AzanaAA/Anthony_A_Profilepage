import styled from 'styled-components';

export const Button = styled.button`
    height: 30px;
    width: 150px;
`;