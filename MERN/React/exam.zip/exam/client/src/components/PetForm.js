import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";


    
const PetForm = () => {
    const [ name, setName ] = useState("");
    const [ type, setType ] = useState("");
    const [ desc, setDesc ] = useState("");
    const [ skill1, setSkill1 ] = useState("");
    const [ skill2, setSkill2 ] = useState("");
    const [ skill3, setSkill3 ] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const handleSubmit = (e) => {
    e.preventDefault();
    axios
    .post("http://localhost:8000/api/pets", { name,type,desc,skill1,skill2,skill3 })
    .then((res) => {
        console.log(res);
        navigate("/");
    })
    .catch((err) => {
        console.log(err.response.data.err.errors);
        setErrors(err.response.data.err.errors);
    });
};



    return (
        <div>
    <Link to="/">Home</Link>
        <form onSubmit={handleSubmit}>
            <div>
            <label htmlFor="name">Name</label>
            <input
            type="text" onChange={(e) => setName(e.target.value)} value={name} />
            {errors.name ? <p>{errors.name.message}</p> : null}
            </div>
            <div>
            <label htmlFor="type">Type</label>
            <input
            type="text" onChange={(e) => setType(e.target.value)} value={type} />
            {errors.name ? <p>{errors.type.message}</p> : null}
            </div>
            <div>
            <label htmlFor="desc">Description</label>
            <input
            type="text" onChange={(e) => setDesc(e.target.value)} value={desc} />
            {errors.name ? <p>{errors.desc.message}</p> : null}
            </div>
            <div>
            <label htmlFor="skill1">Skill 1</label>
            <input
            type="text" onChange={(e) => setSkill1(e.target.value)} value={skill1} />
            
            </div>        
            <div>
            <label htmlFor="skill2">Skill 2</label>
            <input
            type="text" onChange={(e) => setSkill2(e.target.value)} value={skill2} />
            
            </div>
            <div>
            <label htmlFor="skill3">Skill 3</label>
            <input
            type="text" onChange={(e) => setSkill3(e.target.value)} value={skill3} />
            
            </div>
            <button type="submit" >submit</button>
        </form>
        </div>
    )
    }

export default PetForm;