import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams, Link} from "react-router-dom";
    
const DisplayPet = () => {
    const {id} = useParams();
    const [findOne, setPet] = useState([]);
    useEffect(() => {
        axios
        .get(`http://localhost:8000/api/pets/${id}`)
        .then((response) => {
            console.log(response.data);
            setPet(response.data);
        })
        .catch((err) => {
            console.log(err.response);
        });
    }, []);

    const handleDeletePet = (idFromBelow) => {
        axios
        .delete(`http://localhost:8000/api/pets/${idFromBelow}`)
        .then((response) => {
            console.log("success deleting pet");
            console.log(response);
            navigate("/");
            
        })
        .catch((err) => {
            console.log("error deleting pet", err.response);
        });
    };



const navigate = useNavigate();



    return (
        <div>
            <Link to="/">Home</Link>
                <div>
                    <tr key={findOne._id}>
                        <div>
                            
                        <td><p>Details about: {findOne.name}</p></td>
                        </div>
                        <div>
                        <td><p>Type: {findOne.type}</p></td>
                        </div>
                        <div>
                        <td><p>Description: {findOne.desc}</p></td>
                        </div>
                        <div>
                        <td><p>Skill 1: {findOne.skill1}</p></td>
                        </div>
                        <div>
                        <td><p>Skill 2:{findOne.skill2}</p></td>
                        </div>
                        <div>
                        <td><p>Skill 3:{findOne.skill3}</p></td>
                        </div>

                    </tr>
                    <div>
                    <button onClick={() => handleDeletePet(findOne._id)}>Adopt</button>
                    </div>
                    </div>
        </div>
        
    )}

    
export default DisplayPet;