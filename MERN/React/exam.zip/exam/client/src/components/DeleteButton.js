import React from 'react';
import axios from 'axios';


import { Button } from '../styles/Style';
    

const handleDeletePet = (idFromBelow) => {
    axios
    .delete(`http://localhost:8000/api/pets/${idFromBelow}`)
    .then((response) => {
        console.log("success deleting pet");
        console.log(response);
        const filteredPets = allPets.filter((pet) => {
        return pet._id !== idFromBelow;
        });
        setAllPets(filteredPets);
    })
    .catch((err) => {
        console.log("error deleting pet", err.response);
    });
};


return (
    <button onClick={() => handleDeletePet(pet._id)}>Delete</button>
)
