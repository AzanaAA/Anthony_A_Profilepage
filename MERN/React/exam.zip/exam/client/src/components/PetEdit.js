import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useParams,useNavigate } from "react-router-dom";



const EditPet= (props) => {
    const {id} = useParams();
    const [ name, setName ] = useState("");
    const [ type, setType ] = useState("");
    const [ desc, setDesc ] = useState("");
    const [ skill1, setSkill1 ] = useState("");
    const [ skill2, setSkill2 ] = useState("");
    const [ skill3, setSkill3 ] = useState("");
    const [ errors, setErrors ] = useState({});
    const [petNotFoundError, setPetNotFoundError] =  useState("");
    const navigate = useNavigate();
    console.log(id);
    useEffect(() => {
        axios
        .get(`http://localhost:8000/api/pets/${id}`, { name:name,type:type,desc:desc,skill1:skill1,skill2:skill2,skill3:skill3 })
        .then((response) => {
            console.log(response.data);
            setName(response.data.name);
            setType(response.data.type);
            setDesc(response.data.desc);
            setSkill1(response.data.skill1);
            setSkill2(response.data.skill2);
            setSkill3(response.data.skill3);


        })
        .catch((err) => {
            console.log(err.response);
            setPetNotFoundError(`Pet not found using that ID`);
        });
    }, []);


    const submitHandler = (e) => {
        e.preventDefault();

        axios
        .put(`http://localhost:8000/api/pets/${id}`, { name:name,type:type,desc:desc,skill1:skill1,skill2:skill2,skill3:skill3 })
        .then((response) => {
            console.log(response); 
            navigate("/");

        })
        .catch((err) => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        });
    };



    
    return (
        <div>
        <form onSubmit={submitHandler}>
        {petNotFoundError ? (
            <h2>
            {petNotFoundError} <Link to="/new">Click here to add pet</Link>
            </h2>
        ) : null}
        <Link to="/">Home</Link>
            <div>
            <label htmlFor="name">Name</label>
            <input
            type="text" onChange={(e) => setName(e.target.value)} value={name} />
            {errors.name ? <p>{errors.name.message}</p> : null}
            </div>
            <div>
            <label htmlFor="type">Type</label>
            <input
            type="text" onChange={(e) => setType(e.target.value)} value={type} />
            {errors.name ? <p>{errors.type.message}</p> : null}
            </div>
            <div>
            <label htmlFor="desc">Description</label>
            <input
            type="text" onChange={(e) => setDesc(e.target.value)} value={desc} />
            {errors.name ? <p>{errors.desc.message}</p> : null}
            </div>
            <div>
            <label htmlFor="skill1">Skill 1</label>
            <input
            type="text" onChange={(e) => setSkill1(e.target.value)} value={skill1} />
            </div>        
            <div>
            <label htmlFor="skill2">Skill 2</label>
            <input
            type="text" onChange={(e) => setSkill2(e.target.value)} value={skill2} />
            </div>
            <div>
            <label htmlFor="skill3">Skill 3</label>
            <input
            type="text" onChange={(e) => setSkill3(e.target.value)} value={skill3} />
            </div>
            <button type="submit" >submit</button>
        </form>
        </div>
);
};
export default EditPet;