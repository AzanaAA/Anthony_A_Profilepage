import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";



const DisplayAll = () => {
    const [allPets, setAllPets] = useState([]);
    useEffect(() => {
        axios
        .get("http://localhost:8000/api/pets")
        .then((response) => {
            console.log(response.data);
            setAllPets(response.data);
        })
        .catch((err) => {
            console.log(err.response);
        });
    }, []);
    
    const handleDeletePet = (idFromBelow) => {
        axios
        .delete(`http://localhost:8000/api/pets/${idFromBelow}`)
        .then((response) => {
            console.log("success deleting pet");
            console.log(response);
            const filteredPets = allPets.filter((pet) => {
            return pet._id !== idFromBelow;
            });
            setAllPets(filteredPets);
        })
        .catch((err) => {
            console.log("error deleting pet", err.response);
        });
    };

return (
    <div>
    <h3>These pets are looking for a good home</h3>
    <Link to="/new">Add a pet</Link>
    <table>
        <thead>
        <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Actions</th>
        </tr>
        </thead> 
        <tbody>
        {allPets.map((pet, index) => {
                    return (
                    <tr key={pet._id}>
                        <td>{pet.name}</td>
                        <td>{pet.type}</td>
                        <td>
                            <Link to={`/pet/${pet._id}`}>
                            <button>Details</button>
                            </Link>
                        <Link to={`/edit/${pet._id}`}>
                            <button>Edit</button>
                        </Link>
                        
            </td>
            </tr>
        );
        })}
        </tbody>
    </table>
    </div>
);
};

export default DisplayAll;