package com.codingdojo.examthree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamThreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
